from scipy.optimize import minimize, LinearConstraint
from typing import BinaryIO, Dict
from struct import unpack, pack
import datetime as dt
import pandas as pd
import numpy as np
import os



def get_smspec_key_word():
    return get_project_folder() + 'keyword.txt'

class Header:
    """
    класс с данными о заголовке в бинарных файлах, после которых идет информация
    Содержит длинну области размер, одного слова, тип переменных
    """
    length_header = 24  # 24 is size of header
    significant_byte = 16  # 16 is size significant byte area of header

    def __init__(self, keyword: str, number_of_objects: int, datatype: str):
        self.keyword = keyword
        self.number_of_objects = number_of_objects
        self.datatype = datatype
        self.length = None
        self.format = None
        self.start_reading = None
        self.len_reading = None

    def __eq__(self, other):
        if self.keyword == other.keyword:
            return True
        else:
            return False

    @staticmethod
    def __supplement(word: str, must_length: int) -> str:
        if len(word) < must_length:
            supplement = must_length - len(word)
            return word + ' ' * supplement
        elif len(word) >= must_length:
            return word[:must_length]

    def set_limitation(self, start_reading: np.array, len_reading: np.array):
        self.start_reading = start_reading * self.length
        self.len_reading = len_reading * self.length

    def to_byte(self) -> bytes:
        bytes_list = [
            pack('>i', self.significant_byte),
            self.__supplement(self.keyword, 8).encode('utf-8'),
            pack('>i', self.number_of_objects),
            self.__supplement(self.datatype, 4).encode('utf-8'),
            pack('>i', self.significant_byte)
        ]
        return b''.join(bytes_list)

    def get_length_target_bytes(self):
        return self.length * self.number_of_objects

    def get_ending(self):
        if self.start_reading is not None and self.len_reading is not None:
            return self.start_reading + self.len_reading
        else:
            return None


class HeaderConstructor:
    datatype = {'INTE': {'length': 4, 'format': 'i'},
                'LOGI': {'length': 4, 'format': '?'},
                'REAL': {'length': 4, 'format': 'f'},
                'CHAR': {'length': 8, 'format': 'c'},
                'DOUB': {'length': 8, 'format': 'd'}}

    def __byte_init(self, header: Header) -> Header:
        if header.datatype in HeaderConstructor.datatype.keys():
            header.length = self.datatype[header.datatype]['length']
            header.format = self.datatype[header.datatype]['format']
        elif header.datatype[:2] == 'C0':
            header.length = int(header.datatype[2:])
            header.format = 'c'
        else:
            pass
        return header

    def from_bytes(self, binary_info: bytes) -> Header:
        header = Header(
            str(binary_info[4:12], 'utf-8').strip(),
            unpack('>i', binary_info[12:16])[0],
            str(binary_info[16:20], 'utf-8')
        )
        return self.__byte_init(header)

    @staticmethod
    def from_variable(keyword: str, number_of_objects: int,
                      datatype: str) -> Header:
        header = Header(keyword, number_of_objects, datatype)
        hc = HeaderConstructor()
        return hc.__byte_init(header)

    def from_file(self, file: BinaryIO):
        binary_header = file.read(Header.length_header)
        return self.from_bytes(binary_header)


class Content:
    """
    Класс данными бинарных файлов, содержит как заголовок так и данные
    """
    determinant = 4  # 4 is size of zone(area) length determinant

    def __init__(self, header, value):
        self.header = header
        self.value = value

    def __eq__(self, other):
        if self.header.keyword == other.header.keyword:
            return True
        else:
            return False

    @staticmethod
    def __supplement(word: str, must_length: int) -> str:
        if len(word) < must_length:
            supplement = must_length - len(word)
            return word + ' ' * supplement
        elif len(word) >= must_length:
            return word[:must_length]

    def get_length_target_bytes(self) -> int:
        return self.header.length * self.header.number_of_objects

    def get_content(self) -> list or np.array or None:
        return self.value

    def value_to_bytes(self) -> bytes:
        if self.header.format in ['i', 'f']:
            content = []
            for point in self.value:
                content.append(pack('>' + self.header.format, point))
            byte_content = b''.join(content)
        elif self.header.format == 'c':
            content = []
            for point_id, point in enumerate(self.value):
                content.append(self.__supplement(point, self.header.length))
            byte_content = ''.join(content).encode('utf-8')
        else:
            byte_content = b''
        title = pack('>i', len(byte_content))
        return title + byte_content + title

    def to_bytes(self) -> bytes:
        byte_header = self.header.to_byte()
        byte_content = self.value_to_bytes()
        return byte_header + byte_content

    def add_simple_value(self, value: list or tuple) -> None:
        if type(self.value[0]) == list or type(self.value[0]) == tuple:
            self.value.append(value)
        else:
            self.value = [self.value[:]]
            self.value.append(value)
            
    def add_unsmry_value(self, value) -> None:
        if type(self.value[0]) == list or type(self.value[0]) == tuple:
            self.value.append(value)
        else:
            self.value = [self.value[:]]


class ContentConstructor:

    @staticmethod
    def convert(header: Header, binary_info: bytes) -> tuple or list:
        dtype = header.format
        lenformat = header.length
        number = int(len(binary_info)/lenformat)

        if header.format != 'c':
            value = unpack('>' + dtype * number, binary_info)
        else:
            text = str(binary_info, 'utf-8')
            size = header.length
            numb = int(len(text) / header.length)
            value = [text[i * size:(i + 1) * size].strip() for i in range(numb)]
        return value

    @staticmethod
    def get_byte_area(file: BinaryIO, header: Header) -> bytes:
        read = 0
        bytes_list = []
        while read < header.get_length_target_bytes():
            size_area = unpack('>i', file.read(Content.determinant))[0]
            bytes_list.append(file.read(size_area))
            file.seek(Content.determinant, 1)
            read += size_area
        return b''.join(bytes_list)

    def read_definite_part(self, header: Header, file: BinaryIO) -> Content:
        bytedata = self.get_byte_area(file, header)
        bytes_list = []
        ending = header.get_ending()
        for start_id, start in enumerate(header.start_reading):
            if ending[start_id] < len(bytedata):
                bytes_list.append(bytedata[start:ending[start_id]])
            else:
                bytes_list.append(bytedata[start:ending[start_id]])
                break
        content = Content(header, None)
        content.value = self.convert(header, b''.join(bytes_list))
        return content

    def read_all_block(self, header: Header, file: BinaryIO) -> Content:
        content = Content(header, None)
        bytedata = self.get_byte_area(file, header)
        content.value = self.convert(header, bytedata)
        return content

    @staticmethod
    def skip_all_block(header: Header, file: BinaryIO) -> None:
        read = 0
        while read < header.get_length_target_bytes():
            size_area = unpack('>i', file.read(Content.determinant))[0]
            file.seek(size_area + Content.determinant, 1)
            read += size_area

    @staticmethod
    def from_variable(header: Header,
                      value: list) -> Content:
        content = Content(header, value)
        content.star_block = None
        return content

    def from_file(self, header: Header,
                  file: BinaryIO,  mode: str) -> Content or None:

        if mode == 'all':
            return self.read_all_block(header, file)

        elif mode == 'definite' and header.start_reading is not None:
            return self.read_definite_part(header, file)


class BinaryReader:
    #  Универсальный класс для чтения любых бинарных файлов формата eclipse

    def __init__(self, link: str):
        self.link = link
        self.data = dict()
        self.__HeadConst = HeaderConstructor()
        self.__ContConst = ContentConstructor()

    def report(self):
        """
        Отчет о прачитанных данных
        """
        for key in self.data.keys():
            print('Key: {}'.format(key))
            if type(self.data[key]) == Content:
                print('\t{}'.format(self.data[key].value[:100]))
            else:
                print('\t{}'.format(self.data[key]))

    def _add_data(self, content: Content) -> None:
        """
        добавляет в славарь прочитанные данные в соответсвующий экземлпяр класса
        контент или же создает ноый
        :param content: экземлпяр класса контент для записи
        """
        if content.header.keyword in self.data.keys():
            self.data[content.header.keyword].add_simple_value(content.value)
        else:
            self.data[content.header.keyword] = content

    def reload_data(self) -> None:
        """
        Удаляет загруженные данные
        """
        self.data = dict()

    def reading_all_file(self) -> None:
        """
        Читает весь файл
        """
        self.reload_data()
        with open(self.link, 'rb') as file:
            while file.tell() < os.path.getsize(self.link):
                header = self.__HeadConst.from_file(file)
                content = self.__ContConst.from_file(header, file, mode='all')
                self._add_data(content)

    def reading_definite_part(self, keyword: str,
                              start_reading: np.array,
                              len_reading: np.array) -> None:
        """
        Читает заданные позиции из заданного ключевого слова.
         Значительно сокращает время и объем памяти для загрузки информации из
          бинарных файлов по сравнению с последовательной полной загрузкой и
          получением срезов из листо/массивов
        :param keyword: ключевое слово из которого нееобходимо прочитать данные
        :param start_reading: лист с позициями внутри ключевого слова для старта
         чтения
        :param len_reading: лист с количеством слов, которое необходимо
         прочитать при соответсвующем старте

        """

        self.reload_data()
        with open(self.link, 'rb') as file:

            while file.tell() < os.path.getsize(self.link):
                header = self.__HeadConst.from_file(file)
                header.set_limitation(start_reading, len_reading)
                if keyword == header.keyword:
                    content = self.__ContConst.from_file(header, file,
                                                         mode='definite')
                    self._add_data(content)
                else:
                    self.__ContConst.skip_all_block(header, file)

def __value_correct(value: list) -> bool:
    return all(list(map(lambda i: type(value[0]) == type(i), value)))


def __definition_datatype(value: list) -> str or None:
    if __value_correct(value):
        if isinstance(value[0], int):
            return 'INTE'
        elif isinstance(value[0], float):
            return 'REAL'
        elif isinstance(value[0], str):
            return 'CHAR'
        elif isinstance(value[0], bool):
            return 'LOGI'
    elif all(list(map(lambda i: isinstance(i, (float, int)), value))):
        return 'REAL'


def create(link):
    with open(link, 'wb') as _:
        pass


def save(link, keyword, value: list):

    number_of_objects = len(value)

    if keyword == 'PARAMS':
        datatype = 'REAL'
    else:
        datatype = __definition_datatype(value)

    header = HeaderConstructor.from_variable(keyword,
                                             number_of_objects,
                                             datatype)
    content = ContentConstructor.from_variable(header, value)
    bytes_content = content.to_bytes()
    with open(link, 'ab+') as file:
        file.write(bytes_content)


class Storage:
    """
    Класс для хранения ифнормации о порядке записи данных в UNSMRY файлах
    """
    def __init__(self, df: pd.DataFrame, target_name: list):
        self.__df = df
        self.target_name = target_name

    def _get_df(self):
        return self.__df

    def get_number_of_word(self) -> int:
        return self.__df.shape[0]

    def get_time_position(self, keyword) -> np.array:
        keyword_pattern = self.__df['KEYWORDS'] == keyword
        return [self.__df[keyword_pattern].index[0]]

    def get_position(self, name: str or None, keyword: str,
                     num: int or None) -> int:

        keyword_pattern = self.__df['KEYWORDS'] == keyword

        if name is not None:
            name_pattern = self.__df[self.target_name[0]] == name
        else:
            name_pattern = ~self.__df[self.target_name[0]].isnull()

        if num is None:
            num_pattern = ~self.__df['NUMS'].isnull()
        else:
            num_pattern = self.__df['NUMS'] == num

        pattern = name_pattern & keyword_pattern & num_pattern

        return self.__df[pattern].index[0]

    def get_list_position(self, names: list, kwords: list, nums: list) -> list:
        positions = list()

        for name_id, name in enumerate(names):
            keyword = kwords[name_id]
            num = nums[name_id]
            ind = self.get_position(name, keyword, num)
            positions.append(ind)

        return positions

    def get_smsmpec_data(self, keyword):
        return self.__df[keyword]

    def report(self):
        sk = list(self.__df.keys())
        fo = list(pd.unique(self.__df[self.target_name[0]]))
        mk = list(pd.unique(self.__df[self.target_name[1]]))
        print('SMSPEC Keyword:\t{}'.format(sk))
        print('Field Object:\t{}'.format(fo))
        print('Model Keyword (Mnemonic):\t{}'.format(mk))


class StorageConstructor:

    @staticmethod
    def __get_target_name(keys: list) -> list or None:
        if 'WGNAMES' in keys and 'NAMES' not in keys:
            return ['WGNAMES', 'KEYWORDS', 'NUMS', 'UNITS']
        elif 'NAMES' in keys and 'WGNAMES' not in keys:
            return ['NAMES', 'KEYWORDS', 'NUMS', 'UNITS']
        else:
            return None

    @staticmethod
    def from_file(link: str) -> Storage:
        binary_file = BinaryReader(link)
        binary_file.reading_all_file()

        all_key = list(binary_file.data.keys())
        target_key = StorageConstructor.__get_target_name(all_key)

        dict_for_df = dict()
        for key in target_key:
            dict_for_df[key] = binary_file.data[key].value
        df = pd.DataFrame.from_dict(dict_for_df)

        tar_n = target_key
        return Storage(df, tar_n)


class Time:
    """
    класс для хранения и обработки вреиенных шагов
    """
    def __init__(self, start_date, dey_vector, dt_vector):
        self.start_date = start_date
        self.dey_vector = dey_vector
        self.dt_vector = dt_vector

    def get_number_of_step(self) -> int:
        return len(self.dey_vector)

    def report(self):
        print("Start date:\t{}".format(self.start_date))
        print('End date:\t{}'.format(self.dt_vector[-1]))
        print('Number of step:\t{}'.format(self.get_number_of_step()))


class TimeConstructor:
    """
    Класс для создания экземляра класса TIME. Производит чтение из UNSMRY,
     SMSPEC файлов и конвертирует в datatime
    """
    @staticmethod
    def from_file(link: str, storage: Storage) -> Time:

        start_date = TimeConstructor.__get_start_time(link)
        dey_vector = TimeConstructor.__get_time_vec(link, storage)
        dt_vector = TimeConstructor.__conv_to_datetime(start_date, dey_vector)
        return Time(start_date, dey_vector, dt_vector)

    @staticmethod
    def __get_datetime(start_date: dt.datetime, days: float) -> dt.datetime:
        return start_date + dt.timedelta(days=float(days))

    @staticmethod
    def __conv_to_datetime(start_date: dt.datetime,
                           dey_vect: list or np.ndarray) -> list:
        return [TimeConstructor.__get_datetime(start_date, i) for i in dey_vect]

    @staticmethod
    def __get_start_time(link: str) -> dt.datetime:
        binary_file = BinaryReader(link)
        binary_file.reading_all_file()
        start_date = binary_file.data['STARTDAT'].value
        day = start_date[0]
        month = start_date[1]
        year = start_date[2]
        hour = start_date[3]
        minute = start_date[4]
        second = int(start_date[5])
        start_date = dt.datetime(year, month, day, hour, minute, second)
        return start_date

    @staticmethod
    def __get_time_vec(link: str, storage: Storage) -> np.ndarray:
        unsmry_link = link.replace('SMSPEC', 'UNSMRY')
        unsmry = BinaryReader(unsmry_link)
        start = storage.get_time_position('TIME')
        unsmry.reading_definite_part('PARAMS', np.array(start), np.array([1]))
        time_model = np.array(unsmry.data['PARAMS'].value)

        time_model = time_model.T

        if type(time_model[0]) == list or type(time_model[0]) == np.ndarray:
            time_model = time_model[0]

        return time_model


class SMSPECReader:
    """
    Класс для чтения SMSPEC файлов
    Так же в нем в результате храняться данные для чтения из UNSMRY файла
    """
    def __init__(self, link: str):
        self.link = link
        self.storage = None
        self.time = None
        self.dimension = None

    def report(self):
        print('-'*30, 'SMSPEC Report', '-'*30)
        self.storage.report()
        self.time.report()
        print("Dimension\t{}".format(self.dimension))
        print('-' * 75)

    @staticmethod
    def __structuring(for_download: list) -> tuple:
        for_download.sort()
        length = [1]
        start = [for_download[0]]
        for i, point in enumerate(for_download[1:]):
            if point - for_download[i] == 1:
                length[-1] += + 1
            else:
                length.append(1)
                start.append(for_download[i + 1])
        return np.array(start), np.array(length)

    def get_position_matrix(self, names: str or list,
                            keywords: str or list,
                            nums: int or list):
        if type(names) == str or names is None:
            return [names, keywords, nums]
        elif type(names) == list:
            positions_matrix = []
            for name_id, name in enumerate(names):
                keyword = keywords[name_id]

                num = nums[name_id]
                position = self.storage.get_position(name, keyword, num)
                positions_matrix.append([position, name, keyword, num])

            positions_matrix.sort()
            new_position = []
            for position in positions_matrix:
                new_position.append(position[1:])

            return new_position

    def get_read_vector(self, names: str or list,
                        keywords: str or list,
                        nums: int or list) -> tuple:

        if type(names) == str or names is None:
            position = self.storage.get_position(names, keywords, nums)
            return np.array([position]), np.array([1])
        elif type(names) == list:
            positions = []
            for name_id, name in enumerate(names):
                keyword = keywords[name_id]
                num = nums[name_id]
                position = self.storage.get_position(name, keyword, num)
                positions.append(position)
            start, length = self.__structuring(positions)
            return np.array(start), np.array(length)


class SMSPECWorkerConstructor:

    @staticmethod
    def from_file(link: str) -> SMSPECReader:
        smspec = SMSPECReader(link)
        SMSPECWorkerConstructor.__create_storage(smspec)
        SMSPECWorkerConstructor.__create_time(smspec)
        SMSPECWorkerConstructor.__create_dimension(smspec)
        return smspec

    @staticmethod
    def __create_storage(smspec: SMSPECReader) -> None:
        storage = StorageConstructor.from_file(smspec.link)
        smspec.storage = storage

    @staticmethod
    def __create_time(smspec: SMSPECReader) -> None:
        time = TimeConstructor.from_file(smspec.link, smspec.storage)
        smspec.time = time

    @staticmethod
    def __create_dimension(smspec: SMSPECReader) -> tuple:
        number_of_step = len(smspec.time.dey_vector)
        number_of_word = smspec.storage.get_number_of_word()
        smspec.dimension = (number_of_step, number_of_word)
        return number_of_step, number_of_word


"""
Функции для записи в SMSPEC файлы
"""


def create_keyword_vectors(well_names, well_params,
                           well_segments, segment_names, segment_params):
    link = get_smspec_key_word()
    units_df = pd.read_csv(link, sep='\t')
    kwords = ['TIME']
    names = [':+:+:+:+']
    units = ['DAYS']
    nums = [0]

    for param in well_params:
        for well in well_names:
            unit = units_df[units_df['Keyword'] == param]['Unit'].values[0]
            kwords.append(param)
            names.append(well)
            nums.append(0)
            units.append(unit)

    for param in segment_params:
        for w_id, well in enumerate(well_segments):
            segment = segment_names[w_id]
            unit = units_df[units_df['Keyword'] == param]['Unit'].values[0]
            kwords.append(param)
            names.append(well)
            nums.append(segment)
            units.append(unit)

    return kwords, names, nums, units


def create_smspec(link, kwords, names, nums, units, start_date):
    create(link)
    save(link, 'STARTDAT', start_date)
    save(link, 'KEYWORDS', kwords)
    save(link, 'WGNAMES', names)
    save(link, 'NUMS', nums)
    save(link, 'UNITS', units)


def add_in_smspec_file(link, keyword, value):
    save(link, keyword, value)


class SPEcBinaryReader(BinaryReader):
    """
    Модернизация BinaryReader для нужд чтения (ускорения) UNSMRY файлов
    """
    def __init__(self, link: str, dimension: tuple):
        super().__init__(link)
        self.loaded = 0
        self.dimension = dimension
        self.results = None

    def _add_data(self, content: Content) -> None:
        if self.results is None:
            value = content.value
            content.value = np.zeros(self.dimension) * np.nan
            content.value[self.loaded, :] = value
            self.results = content
        else:
            value = content.value
            self.results.value[self.loaded, :] = value
        self.loaded += 1


class UNSMRYLoader:
    """
    Загрузчик файлов из UNSMRY файлов
    """
    def __init__(self, link):
        self.link = link

    def get_from_file(self, start: list, length: list,
                      dimension: tuple) -> np.array or list:
        binary_file = SPEcBinaryReader(self.link, dimension)
        binary_file.reading_definite_part('PARAMS', start, length)
        return binary_file.results.value

"""
Раздел для записи данных в UNSMRY файлов
"""


def create_unsmry(link):
    with open(link, 'wb') as _:
        pass


def add_in_unsmry_file(link, value):
    save(link, 'PARAMS', value)

class SUMMARY:
    def __init__(self, position_matrix: list, data: list or np.array):
        self.position_matrix = position_matrix
        self.data = data

    def report(self):
        for point in self.position_matrix:
            point("Name: {}\t".format(point[0]),
                  'KeyWord: {}\t'.format(point[1]),
                  'Num: {}'.format(point[2]))

    def get_well_param(self, well_name):
        results = dict()

        for so_id, s_object in enumerate(self.position_matrix):
            if well_name == s_object[0]:
                results[s_object[1]] = self.data[:, so_id]

        return results

    def get_segment_param(self, well_name, segment_name):
        results = dict()

        for so_id, s_object in enumerate(self.position_matrix):
            if well_name == s_object[0] and segment_name == s_object[2]:
                results[s_object[1]] = self.data[:, so_id]

        return results

    def get(self, names: str or list, keywords: str or list,
            nums: int or list) -> list or None:

        if type(names) == list:
            results = []
            for name_id, name in enumerate(names):
                keyword = keywords[name_id]
                num = nums[name_id]

                try:
                    ind = self.position_matrix.index([name, keyword, num])
                except ValueError:
                    print("NO VALUE!")
                    return None

                results.append(self.data[ind])
                return results
        else:

            try:
                ind = self.position_matrix.index([names, keywords, nums])
            except ValueError:
                print("NO VALUE!")
                return None

            return self.data[ind]


class SUMMARYReader:
    """
    Класс для чтения SUMMARY файлов.
    """
    def __init__(self, smspec_link: str):
        self.SMSPEC = SMSPECWorkerConstructor.from_file(smspec_link)
        self.UNSMRY = UNSMRYLoader(smspec_link.replace('SMSPEC', 'UNSMRY'))

    def report(self):
        self.SMSPEC.report()

    def __get_dimension(self, names: str or list):
        time_length = self.SMSPEC.time.get_number_of_step()
        if type(names) == list:
            name_length = len(names)
        else:
            name_length = 1
        return time_length, name_length

    def get(self, names: str or list, keywords: str or list,
            nums: int or list) -> SUMMARY:

        start, length = self.SMSPEC.get_read_vector(names, keywords, nums)
        dimension = self.__get_dimension(names)
        data = self.UNSMRY.get_from_file(start, length, dimension)
        position_matrix = self.SMSPEC.get_position_matrix(names, keywords, nums)

        return SUMMARY(position_matrix, data)

    def get_all_vector(self):
        well_name = self.SMSPEC.storage.target_name[0]
        keywords = self.SMSPEC.storage.get_smsmpec_data('KEYWORDS')
        names = self.SMSPEC.storage.get_smsmpec_data(well_name)
        nums = self.SMSPEC.storage.get_smsmpec_data('NUMS')
        return keywords, names, nums

"""
Функии для записи данных с расчтных шагов в бинарные файлы
"""


def create_summary(link, kwords, names, nums, units, start_date):
    create_smspec(link, kwords, names, nums, units, start_date)
    create_unsmry(link.replace('SMSPEC', 'UNSMRY'))


def write_summary(link, value):
    add_in_unsmry_file(link.replace('SMSPEC', 'UNSMRY'), value)


"""
Раздел вспомогательных функций для чтения ASCII файлов
"""


def this_is_skip(line) -> bool:
    """
    Проверяет необходимость пропустить эту строку
    """
    if line == '' or line[:2] == '--':
        return True
    else:
        return False


def clean_from_comment(line: str) -> str:
    """
    Отчищает от комментариев
    """
    line = line.strip().upper()
    line = line.split('--')[0]
    line = line.split('#')[0]
    line = line.split('%')[0]
    return line.strip()


def this_is_end_keyword(line: str) -> bool:
    """
    Проверка строки на конец ключевого слова
    """
    if line == '':
        return False
    else:
        pass

    if line.split()[0].lower() == 'end':
        return True
    else:
        return False


def __read_construction(line: list) -> dict:
    """
    Функция читает строку как строку в которой записаны данные о
     конструкции скважин
    :param line: лист со строкой разделенной по словам для записи
    :return: словарь с прочитанными данными со строки
    """
    try:
        well, bore, segment = line[0], line[1], line[2]
        dev_type, max_size = line[3], line[4]

        inzo = {
            'well': well,
            'bore': bore,
            'segment': segment,
            'device_type': dev_type,
            'fully_open_size': max_size
        }

    except IndexError:
        print('Mistake in inflowzo keyword')
        inzo = {
            'well': None,
            'bore': None,
            'segment': None,
            'device_type': None,
            'fully_open_size': None
        }

    return inzo


def __read_bounds(line: list) -> dict:
    """
    Функция читает строку как строку в которой записаны данные об ограничениях
    :param line: лист со строкой разделенной по словам для записи
    :return: словарь с прочитанными данными со строки
    """

    try:
        well_node = [None, None]
        for well_segment in line[1:-3]:
            if ':' in well_segment:
                well = well_segment.split(':')[0]
                well_segment = well_segment.split(':')[1]
            else:
                well = well_segment
                well_segment = -1

            well_node = [well, well_segment]

        date = line[0]
        fluid, min_liquid, max_liquid = line[-3], line[-2], line[-1]

        border = {
            'date': date,
            'well': well_node[0],
            'valve/segment': int(well_node[1]),
            'min liquid': float(min_liquid),
            'max liquid': float(max_liquid),
            'fluid': fluid
        }

    except IndexError:
        print('Mistake in BOUNDS keyword')
        border = {
            'date': None,
            'well': None,
            'valve/segment': None,
            'min liquid': None,
            'max liquid': None,
            'fluid': None
        }

    return border


def __read_group_list(line: list):
    """
    Функция читает строку как строку, в которой записаны данные о группах
    :param line: лист со строкой разделенной по словам для записи
    :return: словарь с прочитанными данными со строки
    """

    groups = dict()
    try:
        groups[line[0]] = line[1:]
    except IndexError:
        print('Mistake in Group List keyword')

    maximum = 0
    for key in groups.keys():
        len_dict = len(groups[key])
        if len_dict > maximum:
            maximum = len_dict
    for key in groups.keys():
        add_none = maximum - len(groups[key])
        groups[key].extend([None] * add_none)

    return groups


"""
Словарь соответсвия ключевого слова и вызываемой функции
"""

dict_for_fun = {
    'INFLOWZO': __read_construction,
    'BOUNDS': __read_bounds,
    'MAKEGROUPLIST': __read_group_list
}


def this_is_keyword(line: str) -> bool:
    """
    Проверка строки на ключевое слово
    """
    if line.split()[0].upper() in dict_for_fun.keys():
        return True
    else:
        return False


def read_keyword(list_file: list, key: str) -> list:
    """

    :param list_file: лист содержащий строки из файла
    :param key: ключвое слово которое необходимо записать
    :return: словарь с данными записаными в данном ключевом слове
    """

    data = []

    while list_file:

        line = list_file.pop(0)

        while this_is_skip(line) and list_file:
            line = list_file.pop(0)

        if not list_file:
            break

        line = clean_from_comment(line)

        if this_is_end_keyword(line):
            break

        line = clean_from_comment(line)

        if this_is_end_keyword(line):
            break
        if not this_is_skip(line):
            line = line.split()
            target_function = dict_for_fun[key]
            d = target_function(line)
            data.append(d)

    return data


__additional_schedule_name = 'Additional Schedule.INC'


def get_additional_schedule_link() -> str:
    """
    :return: ссылку на файл Additional Schedule.INC
    """
    folder = get_project_folder().replace('/', '\\') + '\\'
    return folder + __additional_schedule_name


def read_additional_schedule() -> dict:
    """
    Чтение файла Additional Schedule.INC
    :return: словарь с разделением по ключевым словам данных прочитанных в файле
    """
    addit_sch = get_additional_schedule_link()
    keyword_data = dict()
    with open(addit_sch, 'r') as file:
        list_file = file.read().split('\n')

        while list_file:
            line = clean_from_comment(list_file.pop(0))

            if this_is_skip(line):
                pass

            elif this_is_keyword(line):
                keyword_data[line] = read_keyword(list_file, line)

    return keyword_data


class MnemonicResults:
    """
    Класс для хранения данных прочитанной конкретной мнемоники
    """
    def __init__(self, well_names, num_names, values, additional):
        self.well = well_names
        self.num = num_names
        self.values = values
        self.for_ind = additional

    def get_param(self, well: str, segm: int or None) -> float:
        """
        Возвращает данные по узлу учета
        :param well: имя скважины
        :param segm: имя зона притока(секгамента)
        :return:
        """
        ind = self.for_ind.index([well, segm])
        return self.values[ind]


class AllMnemonicResults:
    """
    Класс для хранения прочитанных всех мнемоник
    """
    def __init__(self):
        self.param = dict()

    def set_param(self, keyword: str, value: MnemonicResults) -> None:
        self.param[keyword] = value

    def get_param(self, keyword: str, well: str, segm: int or None) -> list:
        return self.param[keyword].get_param(well, segm)


def read_segment_mnemonic(text: str) -> MnemonicResults:
    """
    Ключевое слово для чтения мнемоник сегментов
    :param text: Текст для интерпритации
    :return: экземпляр класса MnemonicResults
    """
    text = str(text)
    text_list = text.split('\n')

    well_names = []
    num_names = []
    values = []
    additional = []

    for line in text_list:

        if 'WELL' in line.upper():
            well_name = line.upper().split(':')[1]
            well_name = well_name.split(',')[0].strip().replace("'", '')
            well_names.append(well_name)
            num_name = line.upper().split(':')[-2]
            num_name = int(num_name.strip().replace("'", ''))
            num_names.append(num_name)
            additional.append([well_name, num_name])

        elif line.upper() != '':
            values.append(float(line.strip()))

    results = MnemonicResults(well_names, num_names, values, additional)
    return results


def read_well_mnemonic(text: str) -> MnemonicResults:

    """
    Ключевое слово для чтения мнемоник скважин
    :param text: Текст для интерпритации
    :return: экземпляр класса MnemonicResults
    """

    text = str(text)
    text_list = text.split('\n')
    well_names = []
    num_names = []
    values = []
    additional = []

    for line in text_list:
        line = line.strip()
        if ':' in line.upper():
            well_name = line.upper().strip().split(':')[0]
            well_names.append(well_name)
            num_names.append(None)
            additional.append([well_name, None])

        elif line.upper() != '':
            values.append(float(line.strip()))

    results = MnemonicResults(well_names, num_names, values, additional)
    return results


def read_target_mnemonic(target_mnemonics: list) -> AllMnemonicResults:
    """
    Читает заданные мнемоник
    :param target_mnemonics: список с необходмыми к прочтению мнемониками
    :return: экзкмпляр класса AllMnemonicResults со всеми записанными данными
    """
    all_results = AllMnemonicResults()

    for mnemonic in target_mnemonics:

        if mnemonic[0].upper() == 'W':
            results = read_well_mnemonic(eval(mnemonic))
        else:
            results = read_segment_mnemonic(eval(mnemonic))

        all_results.set_param(mnemonic, results)

    return all_results


class Approximation:
    @staticmethod
    def x_function(coefficient: np.array, x: np.array) -> np.array:
        print(coefficient, x)
        return coefficient[0] * x

    @staticmethod
    def x2_function(coefficient: np.array, x: np.array) -> np.array:
        print(coefficient, x)
        return coefficient[0] * x ** 2 + coefficient[1] * x

    @staticmethod
    def x3_function(coefficient: np.array, x: np.array) -> np.array:
        f = coefficient[0] * x ** 3
        s = coefficient[1] * x ** 2
        t = coefficient[2] * x
        return f + s + t

    @staticmethod
    def x4_function(coefficient: np.array, x: np.array) -> np.array:
        f = coefficient[0] * x ** 4
        s = coefficient[1] * x ** 3
        t = coefficient[2] * x ** 2
        fo = coefficient[3] * x
        return f + s + t + fo

    @staticmethod
    def deviation(y_experienced: np.array, y_calculated: np.array) -> np.array:
        return sum((y_calculated - y_experienced)**2)

    def function_deviation(self, coefficient: np.array,
                           fun: callable,
                           x_experienced: np.array,
                           y_experienced: np.array) -> np.array:
        y_calculated = fun(coefficient, x_experienced)
        return self.deviation(y_experienced, y_calculated)

    def determine_coefficients(self, fun: callable,
                               first_approach: np.array,
                               x_experienced: np.array,
                               y_experienced: np.array):
        res = minimize(self.function_deviation, first_approach,
                       args=(fun, x_experienced, y_experienced))
        return res


class DebitLimits:

    well = 'well'
    valve = 'valve/segment'
    date = 'date'
    min_vol = 'min liquid'
    max_vol = 'max liquid'
    fluid = 'fluid'

    def __init__(self):
        self.df = None

    def __get_target_value(self, date, well, segment, special_fluid):

        pattern1 = self.df[DebitLimits.well].values == well

        if segment is not None:
            pattern2 = self.df[DebitLimits.valve].values == segment
        else:
            pattern2 = self.df[DebitLimits.valve].isna()

        pattern3 = self.df[DebitLimits.date] <= date
        if special_fluid is None:
            pattern = pattern1 & pattern2 & pattern3
        else:
            pattern4 = self.df[DebitLimits.fluid] == special_fluid
            pattern = pattern1 & pattern2 & pattern3 & pattern4

        return self.df[pattern]

    def get_limit(self, date: dt, well: str, segment: int,
                  special_fluid: str) -> dict:
        """
        Возвращает лимит по текущей скважине из дополнительного расписания.
        :param date: текущая дата
        :param well: имя скважины
        :param segment: имя сегмента приуроченого к данной скважине
        :param special_fluid: имя флюида (нефть/жидкость)
         по которому ищится ограничение
        """
        new_df = self.__get_target_value(date, well, segment, special_fluid)

        if new_df.shape[0] != 0:
            results = {
                DebitLimits.date: date,
                DebitLimits.well: new_df[DebitLimits.well].values[-1],
                DebitLimits.valve: new_df[DebitLimits.valve].values[-1],
                DebitLimits.min_vol: new_df[DebitLimits.min_vol].values[-1],
                DebitLimits.max_vol: new_df[DebitLimits.max_vol].values[-1],
                DebitLimits.fluid: new_df[DebitLimits.fluid].values[-1]
            }
            return results

        else:
            results = {
                DebitLimits.date: date,
                DebitLimits.well: well,
                DebitLimits.valve: segment,
                DebitLimits.min_vol: 0,
                DebitLimits.max_vol: float('inf'),
                DebitLimits.fluid: 'LIQUID'
            }

            return results


class DebitLimitsConstructor:

    @staticmethod
    def create_debit_limits(df: pd.DataFrame) -> DebitLimits:
        """
        Создает экземпляр класса с огрничениями по дебиту нефти и жидкости
        :param df: DataFrame с огрничениями
        :return: экземляр класса DebitLimits
        """
        debit_limits = DebitLimits()
        df = DebitLimitsConstructor.prepare_date(df)
        debit_limits.df = df
        return debit_limits

    @staticmethod
    def prepare_date(df: pd.DataFrame) -> pd.DataFrame:
        """
        Кофектор столбца со временем в формат DataFrame
        :param df: исодный DataFrame
        :return: конвертированный DataFrame
        """
        dates = pd.to_datetime(df[DebitLimits.date])
        df[DebitLimits.date] = dates
        return df

class MyLinearConstraint:

    """
    Класс для подготовки ограничений при оптимизации с использованием scipy
    """
    def __init__(self):
        self.__A = []
        self.__lb = []
        self.__ub = []
        self.__fluid_type = []
        self.__obj = []

    def to_scipy(self) -> LinearConstraint:
        """
        :return: Конвертор в класс предоставляемый scipy
        """
        return LinearConstraint(self.__A, self.__lb, self.__ub)

    def add_bound(self, a: list, lb: float, ub: float,
                  fluid_type: str, obj: str) -> None:
        """
        Добавление данных. организованно совместно, чтобы ничего не потерять
        :param a: вектор коэфицентов A в ограничении lb <= A*X <= ub
        :param lb: нижнее ограничение
        :param ub: верхнее ограничение
        :param fluid_type: тип огричениня по жидкости нефти или воде
        :param obj: устройство/группа/скважина к которому применяется
         ограничение
        """
        self.__A.append(a)
        self.__lb.append(lb)
        self.__ub.append(ub)
        self.__fluid_type.append(fluid_type)
        self.__obj.append(obj)

    def calculate_water_cut(self, water_cut: np.array) -> None:
        """
        используется для получения коэфиуентов в A матрице
        :param water_cut: обводненность или прогнозная обводненность
        """
        self.__A = np.array(self.__A, dtype=float)

        for line_id, line in enumerate(self.__fluid_type):
            if line == 'OIL':
                self.__A[line_id, :] = self.__A[line_id, :] * (1 - water_cut)

            elif line == 'WATER':
                self.__A[line_id, :] = self.__A[line_id, :] * water_cut

    def get_report(self) -> None:
        np.set_printoptions(linewidth=1000, precision=3)
        print("".format(np.array(self.__obj)))
        print("fluid type: {}".format(self.__fluid_type))
        print("min vector: {}".format(self.__lb))
        print("max vector: {}".format(self.__ub))
        print("Bound matix:\n{}".format(self.__A))


def create_linear_constraint():
    return MyLinearConstraint()


def definition_valve_well(wall_name: str, inflow_zone_order: list) -> list:
    """
    :param wall_name: имя скважины
    :param inflow_zone_order: строгий порядок всех контрольных элементов
    :return: лист с именами клапанов в данной скважине
    """
    valve_in_wells = pd.DataFrame(inflow_zone_order, columns=['Well', 'Valve'])
    valve_pattern = valve_in_wells['Well'] == wall_name
    valve_df = valve_in_wells[valve_pattern]
    valve_in_well = pd.unique(valve_df['Valve'])
    return list(valve_in_well)


def get_border_pattern(wells: list, inflow_zone_order: list) -> list:
    border_pattern = [0 for _ in range(len(inflow_zone_order))]

    for well in wells:
        well_valves = definition_valve_well(well, inflow_zone_order)
        for valve in well_valves:
            ind = inflow_zone_order.index([well, valve])
            border_pattern[ind] = 1

    return list(border_pattern)


def __add_object_bound(inflow_zone_order: list,
                       bounds: DebitLimits, now_time: dt,
                       linear_constraint: MyLinearConstraint) -> None:
    """
    Добавляет ограничения для объектов месторождения
    :param inflow_zone_order: строгий порядок контрольных устройств
    :param bounds: экземпляр класса где хранится расписание границ
    :param now_time: текущий расчетный шаг
    :param linear_constraint: данные для записи
    """

    for obj_id, well in enumerate(inflow_zone_order):

        if well[1] != 1:
            well, segment = well[0], well[1]
        else:
            well, segment = well[0], -1

        bound = bounds.get_limit(now_time, well, segment, None)
        border_pattern = [0] * len(inflow_zone_order)
        border_pattern[obj_id] = 1

        linear_constraint.add_bound(border_pattern,
                                    bound[DebitLimits.min_vol],
                                    bound[DebitLimits.max_vol],
                                    bound[DebitLimits.fluid],
                                    well + ':' + str(segment))


def __add_well_bound(constraint: MyLinearConstraint, now_time: dt,
                     bounds: DebitLimits, well: str,
                     inflow_zone_order: list) -> None:
    """
    :param constraint: данные для записи
    :param now_time: текущий расчетный шаг
    :param bounds: экземпляр класса где хранится расписание границ
    :param well: имя скважины
    :param inflow_zone_order: строгий порядок контрольных устройств
    """
    all_valve = definition_valve_well(well, inflow_zone_order)

    if len(all_valve) != 1:
        border_pattern = get_border_pattern([well], inflow_zone_order)
        bound = bounds.get_limit(now_time, well, -1, None)
        constraint.add_bound(border_pattern,
                             bound[DebitLimits.min_vol],
                             bound[DebitLimits.max_vol],
                             bound[DebitLimits.fluid],
                             well)


def __add_field_bound(constraint: MyLinearConstraint,
                      time: dt, bounds: DebitLimits,
                      inflow_zone_order: list,
                      special_fluid) -> None:
    """
    добавляет общие ограничения на скважину
    :param constraint: данные для записи
    :param time: текущий расчетный шаг
    :param bounds: экземпляр класса где хранится расписание границ
    :param inflow_zone_order: строгий порядок контрольных устройств
    """
    bound = bounds.get_limit(time, 'FIELD', -1, special_fluid)
    border_pattern = [1] * len(inflow_zone_order)
    constraint.add_bound(border_pattern,
                         bound[DebitLimits.min_vol],
                         bound[DebitLimits.max_vol],
                         bound[DebitLimits.fluid],
                         'FIELD')


def __add_group_bound(constraint: MyLinearConstraint, time: dt,
                      bounds: DebitLimits, well_list: list, group_name: str,
                      inflow_zone_order: list) -> None:
    """
    добаляет групповые ограничения
    :param constraint: данные для записи
    :param time: текущий расчетный шаг
    :param bounds: экземпляр класса где хранится расписание границ
    :param inflow_zone_order: строгий порядок контрольных устройств
    """
    bound = bounds.get_limit(time, group_name, -1, None)
    border_pattern = get_border_pattern(well_list, inflow_zone_order)

    constraint.add_bound(border_pattern,
                         bound[DebitLimits.min_vol],
                         bound[DebitLimits.max_vol],
                         bound[DebitLimits.fluid],
                         'gr')


def add_bound(time: dt, constraint: MyLinearConstraint,
              bounds: DebitLimits, groups: dict,
              infl_zone_order: list, special_fluid: str) -> None:

    """
    :param constraint: данные для записи
    :param time: текущий расчетный шаг
    :param bounds: экземпляр класса где хранится расписание границ
    :param infl_zone_order: строгий порядок контрольных устройств
    :param groups:
    :param special_fluid: особое указание на тип флюида по которому строется
     ограничение
    """

    __add_object_bound(infl_zone_order, bounds, time, constraint)

    bound_groups = list(pd.unique(bounds.df[DebitLimits.well]))

    for group_id, group in enumerate(bound_groups):

        if group not in list(groups.keys()) and group != 'FIELD':
            well = group
            __add_well_bound(constraint, time, bounds, well, infl_zone_order)

        elif group == 'FIELD':
            __add_field_bound(constraint, time, bounds,
                              infl_zone_order, special_fluid)

        elif group in list(groups.keys()):
            __add_group_bound(constraint, time, bounds,
                              groups[group], group, infl_zone_order)


class Schedule:
    def __init__(self):
        self.bounds = None
        self.groups = None

    def get_boundaries(self, now_time: dt, inflow_zone_order: list,
                       water_cut: np.array, special_fluid: str)\
            -> MyLinearConstraint:
        """

        :param now_time: текущее время
        :param inflow_zone_order: Строгий порядок вывода объектов контроля
        :param water_cut: Обводненность
        :param special_fluid: тип флюида по которому ограничвается месторождение
        :return: экземпляр класса ограничений
        """
        my_linear_constraint = create_linear_constraint()
        add_bound(now_time, my_linear_constraint, self.bounds,
                  self.groups, inflow_zone_order, special_fluid)
        my_linear_constraint.calculate_water_cut(water_cut)

        return my_linear_constraint

    def report(self):

        if self.groups is not None:
            print('-' * 30)
            print(self.groups)

        if self.bounds is not None:
            print(self.bounds.df)
            print('-' * 30)


class ScheduleConstructor:

    @staticmethod
    def create_schedule(additional_data: dict) -> Schedule:
        """
        :param additional_data: словарь с данными загруженными
        из дополниетельного расписания
        :return: экземпляр класса расписания
        """
        schedule = Schedule()

        if 'BOUNDS' in additional_data.keys():
            bounds = additional_data['BOUNDS']
            schedule.bounds = pd.DataFrame(bounds)
            df = ScheduleConstructor.rename(schedule.bounds)
            schedule.bounds = DebitLimitsConstructor.create_debit_limits(df)

        if 'MAKEGROUPLIST' in additional_data.keys():
            groups = additional_data['MAKEGROUPLIST']
            new_groups = dict()
            for group in groups:
                new_groups[list(group.keys())[0]] = group[list(group.keys())[0]]
            schedule.groups = new_groups

        return schedule

    @staticmethod
    def rename(df: pd.DataFrame) -> pd.DataFrame:
        """
        Переименовывает столбцы DataFrame
        :param df: исходный DataFrame
        :return: DataFrame после переименования
        """
        names = list(df.columns)
        names_dict = dict()
        for name in names:
            names_dict[name] = name.lower()

        df.rename(names_dict)
        return df


class InflowZone:
    """
    Зона притока в скважину. Представляет из себя клапан которым можно управлять
    """
    target_params = {
        "well_params": ['WOPR', 'WWPR', 'WWCT', 'WBHP'],
        'valve_params': ['SOFR', 'SWFR', 'SWCT', 'SPR']
    }

    def __init__(self, well: str, bore: str, segment: str, device_type: str,
                 fully_open_size: str):
        """

        :param well: имя скважины на которой находится клапан
        :param bore: номер/имя ствола
        :param segment: номер сегмента который имитирует клапан
        :param device_type: тип устройства
        :param fully_open_size: максимальный размер клапана для установки
        """

        self.well = well
        self.segm = int(segment)
        self.device_type = device_type
        self.max_size = float(fully_open_size)
        self.param = dict()

    def _set_params(self, param: str, param_data: list or np.array):
        """
        Техническая функция используемая при загрузке данных
        :param param: имя мнимоники
        :param param_data: вектор который необходимо загрузить
        """
        self.param[param] = param_data

    def get_param(self, param: str):

        """
        :param param: имя мнимоники
        :return: Возвращает вектор данных за все расчетные шаги
        """
        param = param.upper()

        if param in self.param.keys():
            return self.param[param]
        else:
            print("The requested parameter is missing!")
            return None

    def get_last_active_param(self, param):
        """
        :param param: имя мнимоники
        :return: Возвращает последнее значение при которой работала скважина
        """
        param = param.upper()

        if param in self.param.keys():
            data = self.param[param]
            for point in reversed(data):
                if point > 0:
                    break
            else:
                point = 0
            return point
        else:
            print("The requested parameter is missing!")
            return None

    def set_valve_size(self, share):
        """
        Управляющее слово секции Schedule
        :param share: Доля от максимального размера клапана
        """
        valve_size = "WSEGVALV\n" \
                     "{} {} 1 {}  /\n" \
                     "/""".format(self.well, self.segm,
                                  self.max_size * share)

        add_keyword(valve_size)


class InflowZoneConstructor:
    """
    Класс конструктор для создания (экземпляров) клапанов
    """
    def __init__(self):
        pass

    @staticmethod
    def create(well: str, bore: str, segment: str, device_type: str,
               fully_open_size: str) -> InflowZone:
        """
        Создает эксземляр клапана
        :param well: имя скважины на которой находится клапан
        :param bore: номер/имя ствола
        :param segment: номер сегмента который имитирует клапан
        :param device_type: тип устройства
        :param fully_open_size: максимальный размер клапана для установки
        """
        return InflowZone(well, bore, segment, device_type, fully_open_size)

    @staticmethod
    def from_dict(inflowzone_dict) -> InflowZone:
        """

        :param inflowzone_dict: словарь загруженый из дополнительного расписния,
        в котором указаны данные для создания зоны притока
        :return:
        """

        well = inflowzone_dict['well']
        bore = inflowzone_dict['bore']
        segment = inflowzone_dict['segment']
        device_type = inflowzone_dict['device_type']
        fully_open_size = inflowzone_dict['fully_open_size']

        if fully_open_size == '1*':
            fully_open_size = np.inf
        return InflowZone(well, bore, segment, device_type, fully_open_size)


class Well:
    def __init__(self, name: str):
        self.name = name
        self.InflowZones = dict()
        self.param = dict()

    def get_inflow_zone(self):
        for key in self.InflowZones.keys():
            yield self.InflowZones[key]

    def get_param(self, param: str, inflow_zones: int or None):
        """

        :param param: имя мнимоники
        :param inflow_zones: имя зоны притока, для которой необходимо устоновить
         данный параметр, если это не указано то устанавливает для скважины
        :return:
        """
        if inflow_zones is None:
            return self.param[param]
        else:
            return self.InflowZones[inflow_zones].get_param(param)

    def exercise_control(self, segments, liquid):
        sum_liq = sum(liquid)

        if sum_liq != 0:
            status = 'OPEN'
            weill_control = "WCONPROD\n" \
                            "'{}' {} GRUP 3* 1* 1* 10 0 /\n" \
                            "/".format(self.name, status, sum_liq)
            add_keyword(weill_control)
            weill_control = "WGRUPCON\n" \
                            "'{}' YES {} LIQ 1 /\n" \
                            "/".format(self.name, sum_liq)

            add_keyword(weill_control)
        else:
            status = 'SHUT'
            sum_liq = 0
            weill_control = "WCONPROD\n" \
                            "'{}' {} GRUP 3* 1* 1* 10 0 /\n" \
                            "/".format(self.name, status, sum_liq)
            add_keyword(weill_control)

        max_liq = max(np.abs(liquid))

        if len(list(self.InflowZones.keys())) > 1 and max_liq != 0:
            for s_id, segm in enumerate(segments):

                this_liq = liquid[s_id]
                if this_liq < 0.01 * max_liq:
                    share = 0.01
                else:
                    share = this_liq / max_liq

                self.InflowZones[segm].set_valve_size(share)


class WellConstructor:
    def __init__(self):
        pass

    @staticmethod
    def add_zone(well: Well,  inflow_zone: InflowZone) -> None:
        """
        :param well: объект скважина для который необходимо добавить
        зону притока
        :param inflow_zone: зона притока, которую необходимо добваить
        """
        well.InflowZones[inflow_zone.segm] = inflow_zone

    @staticmethod
    def create_well(name: str, inflow_zones: list or None = None) -> Well:
        """
        Создат объект скважины и устанавливет зону притока
        :param name: имя скважина
        :param inflow_zones: зоны притока этой скважины
        :return: объект скважины
        """
        well = Well(name)
        if inflow_zones is not None:
            for inflow_zone in inflow_zones:
                WellConstructor.add_zone(well, inflow_zone)
        return well

class Field:
    def __init__(self, name: str):
        self.name = name
        self.wells = dict()
        self.bounds = None
        self.Schedule = None

    def get_pattern(self) -> list:
        """
        :return: Возаращает список скважин с зонами притока в стогом порядке
        """
        pattern = []
        wells = list(self.wells.keys())
        wells.sort()

        for well_name in wells:
            inflow_zones = list(self.wells[well_name].InflowZones.keys())
            inflow_zones.sort()
            for inflow_zone in inflow_zones:
                pattern.append([well_name, inflow_zone])

        return pattern

    def get_well(self, unique=True, name=False):
        """

        :param unique: вернуть уникальный список скважин
        :param name: возвращать имена
        :return: возвращает объекты скважин в строгом порядке
        """
        pattern = self.get_pattern()
        pattern = np.array(pattern)
        wells = pattern[:, 0]

        if unique:
            wells = list(set(wells))
            wells.sort()
        if not name:
            for well in wells:
                yield self.wells[well]
        else:
            for well in wells:
                yield self.wells[well].name

    def get_inflow_zone(self):
        """
        :return: Возвращает объекты скважины в строгом порядке
        """
        pattern = self.get_pattern()
        for field_object in pattern:
            well_name = field_object[0]
            segment = field_object[1]
            yield self.wells[well_name].InflowZones[segment]

    def get_well_params(self, param_name, number=None) -> list or int:
        """

        :param param_name: имя параметра который необходимо аернуть
        :param number: какой по счету параметр необходимо вернуть
        :return: возращает или весь соответсвующий вектор или конктерное значеин
         с вызванного шага
        """
        params_list = []

        for well in self.get_well():
            param = well.get_param(param_name, None)

            if number == 'Last':
                params_list.append(param[-1])
            else:
                params_list.append(param)

        return list(params_list)

    def get_inflowzone_params(self, param_name: str, number=None) \
            -> list or int:
        """

        :param param_name: имя параметра который необходимо аернуть
        :param number: какой по счету параметр необходимо вернуть
        :return: возращает или весь соответсвующий вектор или конктерное значеин
         с вызванного шага
        """

        params = []

        for inflow_zone in self.get_inflow_zone():

            well = inflow_zone.well
            segm = inflow_zone.segm
            param = self.wells[well].get_param(param_name, segm)

            if number == 'Last':
                params.append(param[-1])
            else:
                params.append(param)

        return list(params)

    def get_last_active_param(self, param_name):
        """
        возрвщвет вектор значений параметра с последнего шага, на котором
         работала соответсвующая скважина
        :param param_name: имя параметра который необходимо вернуть
        :return: возвращает вектор значений соотсветсвующий строгому порядку
        """
        param_list = []

        for inflowzone in self.get_inflow_zone():
            param = inflowzone.get_last_active_param(param_name)
            param_list.append(param)

        return param_list

    def __liq_limit(self, now_time, swct):
        mlc = self.Schedule.get_boundaries(now_time, self.get_pattern(), swct,
                                           'LIQ')
        return simple_minimization_water(swct, mlc)

    def __oil_limit(self, now_time, swct):
        mlc = self.Schedule.get_boundaries(now_time, self.get_pattern(), swct,
                                           'OIL')
        return simple_minimization_water(swct, mlc)

    def __oil_limit_is_not_met(self, now_time,  liq, swct):
        oil_limit = self.Schedule.bounds.get_limit(now_time, 'FIELD', -1, 'OIL')
        if oil_limit[DebitLimits.max_vol] < sum(liq.x * (1 - swct)):
            return True
        else:
            return False

    @staticmethod
    def exercise_field_control(max_oil, max_liq):
        """

        :param max_oil: максимальное значение дебита нефти на месторождении
        :param max_liq: максимальное значение дебита жидкости на месторождении
        """
        max_oil = max_oil['max liquid']
        max_liq = max_liq['max liquid']
        control = 'GCONPROD\n' \
                  'FIELD ORAT {} 2* {} RATE 5* RATE /\n' \
                  '/'.format(max_oil, max_liq)
        print(control)
        add_keyword(control)

    def exercise_well_control(self, liq):
        pattern = self.get_pattern()
        for well in self.get_well():
            liqu = []
            segm = []
            for segment in well.InflowZones.keys():
                ind = pattern.index([well.name, segment])
                segm.append(segment)
                liqu.append(round(liq.x[ind], 3))

            well.exercise_control(segm, liqu)

            print("{}:\t{}".format(well.name, segm))
            print("{}:\t{}".format(well.name, liqu))

    @staticmethod
    def report_optimization(liq, swct):
        np.set_printoptions(linewidth=1000, precision=3)
        print("Liq: {}".format(np.around(liq.x, 3)))
        print("Oil: {}".format(np.around(liq.x * (1-swct), 3)))
        print("swct: {}".format(swct))
        print("LIQ: {}".format(sum(liq.x)))
        print("OIL: {}".format(sum(liq.x * (1 - swct))))

    def report_param(self):
        for well in self.get_well():
            for key_w in ['WWCT', 'WOPR', 'WOPR', 'WBHP']:
                value = np.array(well.get_param(key_w, None))
                results = '{}, len: {}, value: {}'.format(key_w,
                                                          len(value), value)
                print(results)
            for segm in list(well.InflowZones.keys()):
                for key_w in ['SOFR', 'SWFR', 'SWCT', 'SPR']:
                    value = np.array(well.get_param(key_w, segm))
                    results = '{}, len: {}, value: {}'.format(key_w,
                                                              len(value), value)
                    print(results)

    def __simple_optimization(self, now_t):

        swct = np.array(self.get_last_active_param('SWCT'))
        max_oil = self.Schedule.bounds.get_limit(now_t, 'FIELD', -1, 'OIL')
        max_liq = self.Schedule.bounds.get_limit(now_t, 'FIELD', -1, 'LIQ')

        liq = self.__liq_limit(now_t, swct)
        if self.__oil_limit_is_not_met(now_t, liq, swct):
            liq = self.__oil_limit(now_t, swct)

        self.exercise_field_control(max_oil, max_liq)
        self.exercise_well_control(liq)
        self.report_optimization(liq, swct)

    def optimization(self, now_time, method='Simple'):
        if method == 'Simple':
            self.__simple_optimization(now_time)

    def report(self):
        """
        выводит отчет о созданом объекте местрождения
        """
        print("Name field: {}".format(self.name))
        for well in self.wells:
            well = self.wells[well]
            print('-'*50)
            print("\t Well name: {}".format(well.name))
            for inflowzone in well.InflowZones:
                inflowzone = well.InflowZones[inflowzone]
                print("\t|\t inflowzone: {}\t".format(inflowzone.segm),
                      "Device Type: {}".format(inflowzone.device_type))

        self.Schedule.report()

    def get_save_order(self) -> tuple:
        """
        :return: возвращает вектора c порядком сохраненя в бинарных файлах
        """
        w_names = list(self.get_well(name=True))
        w_params = InflowZone.target_params['well_params']
        s_params = InflowZone.target_params['valve_params']

        s_well = []
        s_name = []
        for infzone in self.get_inflow_zone():
            s_well.append(infzone.well)
            s_name.append(infzone.segm)

        return w_names, w_params, s_well, s_name, s_params


class FieldConstructor:

    @staticmethod
    def get_smspec_link() -> str:
        """
        :return: Возвращает ссылку на SMSPEC файл
        """
        this_folder = get_project_folder() + '\\'
        return this_folder + 'tNavigatorManager.SMSPEC'

    @staticmethod
    def get_unsmry_link() -> str:
        """
        :return: Возвращает ссылку на UNSMRY файл
        """
        this_folder = get_project_folder() + '\\'
        return this_folder + 'tNavigatorManager.UNSMRY'

    @staticmethod
    def __create_empty_field(name: str) -> Field:
        """
        Создан для больщей абстаркии при инициализации метсорождениия и
         простоты дальнейшего расширения скрипта
        :param name: имя месторождения
        :return: возвращает пустой объект месторождения
        """
        return Field(name)

    @staticmethod
    def __add_schedule(field: Field, additional_data: dict) -> None:
        """
        Создан для больщей абстаркии при инициализации метсорождениия и
         простоты дальнейшего расширения скрипта
        :param field: объект месторождения к которому необходимо добавить
         объект скважины
        :param additional_data: данный необходимые для создания объекта скважины
        """

        schedule = ScheduleConstructor.create_schedule(additional_data)
        field.Schedule = schedule

    @staticmethod
    def __add_well(field: Field, well: Well) -> None:
        """
        Создан для больщей абстаркии при инициализации метсорождениия и
         простоты дальнейшего расширения скрипта
        :param field: объект месторождения к которому необходимо добавить
         объект скважины
        :param well: объект скважины для добавления
        """
        field.wells[well.name] = well

    @staticmethod
    def __add_inflowzone(field: Field, inflowzone: InflowZone) -> None:
        """
        :param field: объект месторождения к которому необходимо добавить
         объект зону притока(клапан)
        :param inflowzone: объект зона притока(клапан) для добавления
        """

        if inflowzone.well not in field.wells:
            well = WellConstructor.create_well(inflowzone.well)
            WellConstructor.add_zone(well, inflowzone)
            FieldConstructor.__add_well(field, well)
        else:
            well = field.wells[inflowzone.well]
            WellConstructor.add_zone(well, inflowzone)

    @staticmethod
    def __read_additional_schedule(field) -> None:
        """
        :param field: объект месторождения к которому необходимо добавить данные
        из дополнительного расписания
        """
        additional_data = read_additional_schedule()

        for inflowzone in additional_data['INFLOWZO']:
            inflowzone = InflowZoneConstructor.from_dict(inflowzone)
            FieldConstructor.__add_inflowzone(field, inflowzone)

        FieldConstructor.__add_schedule(field, additional_data)

    @staticmethod
    def __for_read_in_summ_file(field) -> tuple:
        """

        :param field: объект месторождения,
        :return: возвращает ветора для записи в бинарные файлы
        """
        wells, main_params, nums = [], [], []

        for well in field.get_well():
            for param in InflowZone.target_params['well_params']:
                wells.append(well.name)
                main_params.append(param)
                nums.append(None)

            for inflow_zone in well.get_inflow_zone():
                for param in InflowZone.target_params['valve_params']:
                    wells.append(inflow_zone.well)
                    main_params.append(param)
                    nums.append(inflow_zone.segm)

        return wells, main_params, nums

    @staticmethod
    def __create_summry(field, start_d) -> None:
        """
        Создает smspec, unsmry файлы для записи результатов
        :param field: объект месторождения из которого берется шаблон для записи
        :param start_d: стартовая дата
        """

        smspec_file = FieldConstructor.get_smspec_link()
        unsmry_file = FieldConstructor.get_unsmry_link()

        w_name, w_param, s_well, s_name, s_param = field.get_save_order()
        targ = create_keyword_vectors(w_name, w_param, s_well, s_name, s_param)

        create_summary(smspec_file, targ[0], targ[1], targ[2], targ[3], start_d)
        write_summary(unsmry_file, [0] * len(targ[0]))

    @staticmethod
    def __save_new_data(field) -> None:
        """
        Сохраняет данные в smspec, unsmry файлы из мнимоник API tNavigator
        :param field: объект месторождения из которого берется шаблон для записи
        """

        smspec_file = FieldConstructor.get_smspec_link()
        unsmry_file = FieldConstructor.get_unsmry_link()

        summary_reader = SUMMARYReader(smspec_file)
        w_name, w_param, s_well, s_name, s_param = field.get_save_order()
        targ = create_keyword_vectors(w_name, w_param, s_well, s_name, s_param)

        target_mnemonics = InflowZone.target_params['well_params'][:]
        target_mnemonics.extend(InflowZone.target_params['valve_params'])
        all_mnemonic_results = read_target_mnemonic(target_mnemonics)
        now_dat = get_current_date()
        start_d = summary_reader.SMSPEC.time.start_date

        values = [(now_dat - start_d).days]

        for k_id, keyword in enumerate(targ[0]):
            if k_id != 0:
                well = targ[1][k_id]
                segm = targ[2][k_id]
                if segm == 0:
                    segm = None
                value = all_mnemonic_results.get_param(keyword, well, segm)
                values.append(value)

        write_summary(unsmry_file, values)

    @staticmethod
    def __read_summary_file(field: Field) -> None:
        """
        Читает данные из smspec, unsmry файлой
        :param field: объект месторождения для записи
        """

        smspec_file = FieldConstructor.get_smspec_link()

        summary_reader = SUMMARYReader(smspec_file)
        wells, params, nums = FieldConstructor.__for_read_in_summ_file(field)
        summary = summary_reader.get(wells, params, nums)

        for well in field.get_well():
            well.param = summary.get_well_param(well.name)

        for inflow_zone in field.get_inflow_zone():
            inflow_zone.param = summary.get_segment_param(inflow_zone.well,
                                                          inflow_zone.segm)

    @staticmethod
    def create_field() -> Field:
        """
        :return: Создает объект месторожедния со всеми данными
        """
        field = FieldConstructor.__create_empty_field('name')
        FieldConstructor.__read_additional_schedule(field)
        FieldConstructor.__save_new_data(field)
        FieldConstructor.__read_summary_file(field)
        return field

    @staticmethod
    def create_field_for_init() -> Field:
        """
        :return: Возвращаетобъект месторождения для __init_script__
        """
        field = FieldConstructor.__create_empty_field('name')
        FieldConstructor.__read_additional_schedule(field)
        start_date = get_current_date()
        d = start_date.day
        m = start_date.month
        y = start_date.year
        start_date = [d, m, y, 0, 0, 0]
        FieldConstructor.__create_summry(field, start_date)
        return field


def target_function(liquid_x, water_cut):
    return sum(liquid_x * water_cut)


def derivative_vector(_, water_cut):
    return water_cut


def simple_minimization_water(water_cut, my_linear_constraint):
    first_approach = np.ones(len(water_cut)) * 0.1
    # print(my_linear_constraint.get_report())
    linear_constraint = my_linear_constraint.to_scipy()
    sol = minimize(target_function, x0=first_approach, args=(water_cut,),
                   constraints=[linear_constraint],
                   method='SLSQP', jac=derivative_vector)
    return sol

def __init_script__():
    field = FieldConstructor.create_field_for_init()
    field.report()
    print('Успешно инициализированно!')


def alg():
    field = FieldConstructor.create_field()
    print('Модель управления успешно создана!')
    t = get_current_date()
    field.optimization(t, 'Simple')
    field.report_param()
    print('Алгоритм успшно реализован!')


__init_script__()

alg()
