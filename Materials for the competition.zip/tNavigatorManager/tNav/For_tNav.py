

def get_smspec_key_word():
    return get_project_folder() + 'keyword.txt'
